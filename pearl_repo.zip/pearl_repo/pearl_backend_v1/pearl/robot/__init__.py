"""Robot adapters: `interface.RobotInterface` is implemented by `ros2_robot.Ros2Robot` (real) and `stub_robot.StubRobot` (simulation)."""
