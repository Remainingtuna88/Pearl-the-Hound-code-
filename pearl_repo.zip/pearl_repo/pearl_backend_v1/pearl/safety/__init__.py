"""Layer 4 — hard safety floor. Sits BENEATH the action layer."""
