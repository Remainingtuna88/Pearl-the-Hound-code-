"""Layer 5 — HTTP bridge (Flask) consumed by the remote dashboard."""
