"""Layer 2 — planner: LFM2.5-230M via llama.cpp choosing actions from the vocabulary in actions/goal.py."""
