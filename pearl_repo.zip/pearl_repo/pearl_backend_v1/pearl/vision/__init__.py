"""Layer 1 — vision: VLM identity verification (slow, periodic) + classical tracker (cheap, frequent)."""
