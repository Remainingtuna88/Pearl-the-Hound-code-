"""Pearl Backend V1 — search-and-locate robot backend. Entry point: run.py / pearl.app.main()."""
__version__ = "0.1.0"
