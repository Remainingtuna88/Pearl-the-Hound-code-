"""Layer 3 — action layer. See actions/manager.py for the design overview."""
